Bismuth Readme
=======

Official website:
* http://bismuth.cz

This package includes parts of the Bismuth node which are required by some daps.
Currently it includes:


- connecitons.py
- essentials.py
- options.py